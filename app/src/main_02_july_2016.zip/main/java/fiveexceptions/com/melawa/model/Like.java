package fiveexceptions.com.melawa.model;

/**
 * Created by amit on 27/4/16.
 */
public class Like {

}
