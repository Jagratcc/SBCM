package fiveexceptions.com.melawa.activities;

/**
 * Created by amit on 2/5/16.
 */
public interface TabInterface {


    public void refeshWhenScroll(boolean doForceRefresh);
    public void refreshWithAdvSearch();

}
