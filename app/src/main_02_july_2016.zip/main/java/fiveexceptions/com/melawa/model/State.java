package fiveexceptions.com.melawa.model;

/**
 * Created by amit on 13/4/16.
 */
public class State {
      public   int id;
     public  String name;

    public State(int id, String name) {
        this.id = id;
        this.name = name;
    }
}
