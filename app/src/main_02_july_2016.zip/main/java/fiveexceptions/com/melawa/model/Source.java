package fiveexceptions.com.melawa.model;

/**
 * Created by amit on 13/4/16.
 */
public class Source {
 public   int id;
  public  String name;

    public Source(int id, String name) {
        this.id = id;
        this.name = name;
    }
}
