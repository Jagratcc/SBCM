package fiveexceptions.com.melawa.model;

/**
 * Created by amit on 9/4/16.
 */
public class Profile {



    int     profileId;
    String  candidateName;
    String  fatherName;
    String  motherName;
    boolean profileType;
    String  dateBirth;
    String  cityBirth;
    String  cityRes;
    int     age;
    String  color;
    String  hight;
    String  motherTounge;
    String  cast;
    String  managlik;
    String  education;
    String  income;
    String  profession;
    String  address;
    String  contectNo;
    String  source;
    // Drawable image;
    String  region;
    boolean maritialStatus;
    String  discription;
    int     flag;
    String thumbnailImgName;
    String fullImgName;
    String  expectation;
    String birthdisplaydate;

    public Profile() {
    }

    public int getProfileId() {
        return profileId;
    }

    public void setProfileId(int profileId) {
        this.profileId = profileId;
    }

    public String getCandidateName() {
        return candidateName;
    }

    public void setCandidateName(String candidateName) {
        this.candidateName = candidateName;
    }

    public String getFatherName() {
        return fatherName;
    }

    public void setFatherName(String fatherName) {
        this.fatherName = fatherName;
    }

    public String getMotherName() {
        return motherName;
    }

    public void setMotherName(String motherName) {
        this.motherName = motherName;
    }

    public boolean isProfileType() {
        return profileType;
    }

    public void setProfileType(boolean profileType) {
        this.profileType = profileType;
    }

    public String getDateBirth() {
        return dateBirth;
    }

    public void setDateBirth(String dateBirth) {
        this.dateBirth = dateBirth;
    }

    public String getCityRes() {
        return cityRes;
    }

    public void setCityRes(String cityRes) {
        this.cityRes = cityRes;
    }

    public String getCityBirth() {
        return cityBirth;
    }

    public void setCityBirth(String cityBirth) {
        this.cityBirth = cityBirth;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getHight() {
        return hight;
    }

    public void setHight(String hight) {
        this.hight = hight;
    }

    public String getMotherTounge() {
        return motherTounge;
    }

    public void setMotherTounge(String motherTounge) {
        this.motherTounge = motherTounge;
    }

    public String getCast() {
        return cast;
    }

    public void setCast(String cast) {
        this.cast = cast;
    }

    public String getManaglik() {
        return managlik;
    }

    public void setManaglik(String managlik) {
        this.managlik = managlik;
    }

    public String getEducation() {
        return education;
    }

    public void setEducation(String education) {
        this.education = education;
    }

    public String getIncome() {
        return income;
    }

    public void setIncome(String income) {
        this.income = income;
    }

    public String getProfession() {
        return profession;
    }

    public void setProfession(String profession) {
        this.profession = profession;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getContectNo() {
        return contectNo;
    }

    public void setContectNo(String contectNo) {
        this.contectNo = contectNo;
    }

    /*
    public Drawable getImage() {
        return image;
    }

    public void setImage(Drawable image) {
        this.image = image;
    }
    */

    public String getBirthdisplaydate() {
        return birthdisplaydate;
    }

    public void setBirthdisplaydate(String birthdisplaydate) {
        this.birthdisplaydate = birthdisplaydate;
    }



    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public boolean isMaritialStatus() {
        return maritialStatus;
    }

    public void setMaritialStatus(boolean maritialStatus) {
        this.maritialStatus = maritialStatus;
    }

    public String getDiscription() {
        return discription;
    }

    public void setDiscription(String discription) {
        this.discription = discription;
    }



    public int getFlag() {
        return flag;
    }

    public void setFlag(int flag) {
        this.flag = flag;
    }

    public String getThumbnailImgName() {
        return thumbnailImgName;
    }

    public void setThumbnailImgName(String thumbnailImgName) {
        this.thumbnailImgName = thumbnailImgName;
    }

    public String getFullImgName() {
        return fullImgName;
    }

    public void setFullImgName(String fullImgName) {
        this.fullImgName = fullImgName;
    }


    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }


    public String getExpectation() {
        return expectation;
    }

    public void setExpectation(String expectation) {
        this.expectation = expectation;
    }
}

