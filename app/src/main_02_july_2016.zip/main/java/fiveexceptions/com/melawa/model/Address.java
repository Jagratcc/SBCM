package fiveexceptions.com.melawa.model;

/**
 * Created by amit on 27/5/16.
 */
public class Address {

  public   String address;

  public Address(String address) {
    this.address = address;
  }


  public String getAddress() {
    return address;
  }



  public void setAddress(String address) {
    this.address = address;
  }
}
