package fiveexceptions.com.melawa.model;

/**
 * Created by amit on 25/5/16.
 */
public class Region {


    public   int id;
    public  String name;

    public Region(int id, String name)

    {
        this.id = id;
        this.name = name;
    }




}
