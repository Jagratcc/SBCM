package fiveexceptions.com.melawa.activities;

/**
 * Created by amit on 2/5/16.
 */
public interface SyncInterface {

    public void syncResult(boolean result, int responseCode, String msg);

}
